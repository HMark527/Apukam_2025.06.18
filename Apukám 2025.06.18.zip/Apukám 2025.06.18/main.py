import time

def main() -> None:
    
    print("Boldog névnapot Apukám! Nagyon szeretlek!")
    print("Jöhetnek a feladatok?")
    print("1: igen; 2: nem")
    melyik: int = int(input("1 vagy 2: "))
    if melyik == 2:
        print("Biztos?")
        print("1: igen; 2: nem")
        melyik: int = int(input("1 vagy 2: "))
        if melyik == 2:
            print("Akkor kezdődjék a feladat megoldás!\n")
    else:
        print("Akkor kezdődjék a feladat megoldás!\n")
    print("FONTOS infók: minden szöveges kérdésre nagy kezdőbetűvel válaszolj, a többi betű legyen kicsi!\nA válaszaidat MINDIG írd fel valahova!")
    megoldások: list[int] = [1, 2, 2, 4, 4, 1, 45, 0, 1936, 2116, 1, 2, 9, 2, 2, 233, 256, 21760, 8, 151, 2, 1024, 2, 2, 93026, 32768, 151423]
    válaszok: list[int] =[]
    start = time.perf_counter()

    print("Milyen színűre van beállítva a pc-m világítása?")
    print("1: kék; 2: zöld; 3: piros; 4: sárga")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index: int = 0
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")
    
    print("Melyik a 15. szuperprím?")
    print("1: 211; 2: 241; 3: 277; 4: 331")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Melyik a 2. tökéletes szám?")
    print("1: 6, 2: 28, 3: 496")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hányszor szerepel a 'hányszor' vagy 'Hányszor' szó a Himnszban?")
    print("1: 5; 2: 4; 3: 3; 4: 2; 5: 1")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hány additív prímszám van 100 alatt?")
    print("1: 9; 2: 11; 3: 12; 4: 14")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    összpont: int = 0
    akt_részben_pontok: int = 0
    for e in range(0, 5):
        if megoldások[e] == válaszok[e]:
            akt_részben_pontok += 1
            összpont += 1
    if akt_részben_pontok == 5:
        print("jpzes\n")
    else:
        print("Sajnos ezt az ajándékot ezúttal nem szerezted meg!\n")

    print("És ezek között hány szuperprím található?")
    print("1: 5; 2: 4; 3: 3; 4: 2; 5: 1")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("2025-ig hány évszam (volt) négyzetszám?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")
        
    print("A jelelegi év évszáma négyzetszám?")
    print("0: 1; 1: 0")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")
        
    print("Melyik év volt az előző 'négyzetszámos év'?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Melyik év lesz a következő 'négyzetszámos év'?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("1489 biztonságos prím?")
    print("1823: 1; 1: 0")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hány bölcsföldi-prím van 1000-ig?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    akt_részben_pontok = 0
    for e in range(5, 12):
        if megoldások[e] == válaszok[e]:
            akt_részben_pontok += 1
            összpont += 1
    if akt_részben_pontok == 7:
        print("ódragrb\n")
    else:
        print("Sajnos ezt az ajándékot ezúttal nem szerezted meg!\n")

    print("Hány félprím van 25-ig?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    
    print("1176 háromszögszám?")
    print("1: ali; 2: Taip")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("15917 csillagprím?")
    print("1: persze; 2: dehogy")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("6. Fibonacci-prím?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hány magos lesz az új bivaly AMD EPYC szerver-cpu?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hány mag van az RTX 5090-ben?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hány mag van általában egy telefon processzorában?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("8. palindrom-prím?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    akt_részben_pontok = 0
    for e in range(12, 20):
        if megoldások[e] == válaszok[e]:
            akt_részben_pontok += 1
            összpont += 1
    if akt_részben_pontok == 8:
        print("zslőbae\n")
    else:
        print("Sajnos ezt az ajándékot ezúttal nem szerezted meg!\n")

    print("Bence melyik hányadik szülinapjára emlékeztetett bennünket?")
    print("Sima számmal válaszolj!")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("1 Exabyte hányszor 1024 Terabyte?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Ki idősebb: Máté vagy Minecraft?")
    print("1: Máté; 2: Minecraft")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Magyarország jelenleg hányadik évezredében van?")
    print("Sima számmal válaszolj!")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hány km2 Magyarország területe?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Hány MB VRAM van az RTX 5090-ben?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    print("Mennyi az összes eddig feltett kérdés helyes válaszainak összege?")
    akt_válasz: int = int(input(""))
    válaszok.append(akt_válasz)
    kérdés_index += 1
    if megoldások[kérdés_index] == válaszok[kérdés_index]:
        print("Helyes a válasz!\n")
    else:
        print("Sajnálom! Ez most nem lett jó!\n")


    print("Melyik az AMD legerősebb általános felhasználásra szánt CPU-ja?")
    a: str = input("")
    if a == "Ryzen 9 9950X3D":
        print("Helyes a válasz!\n")
        akt_részben_pontok += 1
        összpont += 1
    else:
        print("Sajnálom! Ez most nem lett jó!\n")
    

    print("Melyik adattárolási egység 1 000 000 000 szorosa a Terabyte-nak?")
    b: str = input("")
    if b == "Zettabyte":
        print("Helyes a válasz!\n")
        akt_részben_pontok += 1
        összpont += 1
    else:
        print("Sajnálom! Ez most nem lett jó!\n")
    
    print("Melyik 2017-ben megjelent GPU-t neveznek legendának?")
    c: str = input("")
    if c == "GTX 1080 Ti":
        print("Helyes a válasz!\n")
        akt_részben_pontok += 1
        összpont += 1
    else:
        print("Sajnálom! Ez most nem lett jó!\n")
    
    print("ZTT néző közönségének kedvenc GPU-ja?")
    d: str = input("")
    if d == "Ryzen 4070":
        print("Helyes a válasz!\n")
        akt_részben_pontok += 1
        összpont += 1
    else:
        print("Sajnálom! Ez most nem lett jó!\n")

    end = time.perf_counter()

    if összpont == 30 and end - start < 300:
        print("Gratulálok! Sikeresen teljesítetted ezt az ajándékot!")
        print("ailnppa\n")
        print(f"A teljes megoldási időd: {(end - start):.2f} másodperc.")
        print(f"A pontszámod: {összpont}/30.")
        print(f"{(float(összpont) / 30):.2f}%\n")
    else:
        print("Sajnos ezt az ajándékot ezúttal nem szerezted meg!")
        print("Mert nem volt minden válaszod helyes vagy 3 percnél több időt töltöttél a feladatsor megoldásával!")
        print(f"A teljes megoldási időd: {(end - start):.2f} másodperc.")
        print(f"A pontszámod: {összpont}/30.")
        print(f"{(float(összpont) / 30):.2f}%\n")

    print("Ha érdekel, itt egy olyan dolog, ami engem megdöbentett: https://hu.wikipedia.org/wiki/Soksz%C3%B6gsz%C3%A1mok")
if __name__ == "__main__":
    main()